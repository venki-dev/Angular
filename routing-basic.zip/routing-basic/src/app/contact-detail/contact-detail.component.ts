import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ContactsService } from './../contacts.service';
import { Contact } from './../contact';



@Component({
  selector: 'app-contact-detail',
  templateUrl: './contact-detail.component.html',
  styleUrls: ['./contact-detail.component.css']
})
export class ContactDetailComponent implements OnInit {

  contact: Contact;
  constructor(private service: ContactsService, private route: ActivatedRoute) { }

  ngOnInit() {

    this.route.params.subscribe(param => {

      this.service.getContact(Number(param.id)).subscribe(res => {
        console.log('Success in getContact', param.id, res);
        this.contact = res;
      }, err => {
        console.log('Error in getContact');
      })
    })

  }

}
