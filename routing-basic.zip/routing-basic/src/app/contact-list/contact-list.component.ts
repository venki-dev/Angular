import { Component, OnInit } from '@angular/core';
import { ContactsService } from './../contacts.service';
import { Contact } from './../contact';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  contacts: Contact[];
  constructor(private service: ContactsService) { }

  ngOnInit() {
    this.service.getContacts().subscribe(res => {
      console.log('Success in getContacts');
      this.contacts = res;
    }, err => {
      console.log('Error in getContacts');
    }) 
  }

}
