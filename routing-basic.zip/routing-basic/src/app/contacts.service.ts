import { Injectable } from '@angular/core';

import { Contact } from './contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {
  contacts: Contact[] = [
    { id: 1, name: 'Contact 1', email: 'contact1@email.com' },
    { id: 2, name: 'Contact 2', email: 'contact2@email.com' },
    { id: 3, name: 'Contact 3', email: 'contact3@email.com' },
    { id: 4, name: 'Contact 4', email: 'contact4@email.com' }
  ];
  constructor() { }

  getContacts() {
    return Observable.create(observer => {
      observer.next(this.contacts);
    });
  }

  getContact(id) {
    const contact = this.contacts.filter(item => item.id === id);
    return Observable.create(observer => {
      observer.next(contact[0]);
    })
  }
}
