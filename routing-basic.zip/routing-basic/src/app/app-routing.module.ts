import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ContactListComponent } from './contact-list/contact-list.component'
import { ContactDetailComponent } from './contact-detail/contact-detail.component'
import { AddressComponent } from './address/address.component'
import { PageNotFoundComponent } from './page-not-found/page-not-found.component'

const routes: Routes = [{
    path: '', redirectTo: 'contacts', pathMatch: 'full'
}, {
    path: 'contacts', component: ContactListComponent
}, {
    path: 'contact/:id', component: ContactDetailComponent
}, {
    path: 'address', component: AddressComponent
},
{
    path: '**', component: PageNotFoundComponent
}];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRouterModule { }
