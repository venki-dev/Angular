import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-builder-form-control',
  templateUrl: './form-builder-form-control.component.html',
  styleUrls: ['./form-builder-form-control.component.css']
})
export class FormBuilderFormControlComponent implements OnInit {
  regForm: FormGroup;
  submitted: boolean;
  constructor(private fb: FormBuilder) {
    this.submitted = false;
  }

  ngOnInit() {
    this.regForm = this.fb.group({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),

      address: this.fb.group({
        street: new FormControl('', [Validators.required]),
        city: new FormControl(''),
      })
    });
  }

  get f() {
    return this.regForm.controls;
  }

  submitForm() {
    this.submitted = true;
    if (this.regForm.invalid) {
      return;
    }

    console.log(this.regForm.value);

  }

}
