import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBuilderFormControlComponent } from './form-builder-form-control.component';

describe('FormBuilderFormControlComponent', () => {
  let component: FormBuilderFormControlComponent;
  let fixture: ComponentFixture<FormBuilderFormControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBuilderFormControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBuilderFormControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
