import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormGroupFormControlComponent } from './form-group-form-control.component';

describe('FormGroupFormControlComponent', () => {
  let component: FormGroupFormControlComponent;
  let fixture: ComponentFixture<FormGroupFormControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormGroupFormControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormGroupFormControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
