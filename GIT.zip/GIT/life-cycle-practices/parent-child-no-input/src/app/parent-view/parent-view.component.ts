import {
  Component,
  OnInit, OnChanges, DoCheck,
  AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy
} from '@angular/core';

@Component({
  selector: 'app-parent-view',
  templateUrl: './parent-view.component.html',
  styleUrls: ['./parent-view.component.css']
})
export class ParentViewComponent implements 
  OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

  constructor() { 
    console.log('[ParentViewComponent] - constructor');
  }

  ngOnChanges() {
    console.log('[ParentViewComponent] - ngOnChanges');

  }

  ngOnInit() {
    console.log('[ParentViewComponent] - ngOnInit');

  }

  ngDoCheck() {
    console.log('[ParentViewComponent] - ngDoCheck');
  }
  
  ngAfterContentInit() {
    console.log('[ParentViewComponent] - ngAfterContentInit');

  }

  ngAfterContentChecked() {
    console.log('[ParentViewComponent] - ngAfterContentChecked');
  }

  ngAfterViewInit() {
    console.log('[ParentViewComponent] - ngAfterViewInit');
  }

  ngAfterViewChecked() {
    console.log('[ParentViewComponent] - ngAfterViewChecked');
  }

  ngOnDestroy() {
    console.log('[ParentViewComponent] - ngOnDestroy');
  }

}
