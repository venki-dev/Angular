import {
  Component,
  OnInit, OnChanges, DoCheck,
  AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy
} from '@angular/core';

@Component({
  selector: 'app-child-view',
  templateUrl: './child-view.component.html',
  styleUrls: ['./child-view.component.css']
})
export class ChildViewComponent implements
  OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {


  constructor() {
    console.log('[ChildViewComponent] - constructor');
  }

  ngOnChanges() {
    console.log('[ChildViewComponent] - ngOnChanges');

  }

  ngOnInit() {
    console.log('[ChildViewComponent] - ngOnInit');
  }

  ngDoCheck() {
    console.log('[ChildViewComponent] - ngDoCheck');
  }

  ngAfterContentInit() {
    console.log('[ChildViewComponent] - ngAfterContentInit');

  }

  ngAfterContentChecked() {
    console.log('[ChildViewComponent] - ngAfterContentChecked');
  }

  ngAfterViewInit() {
    console.log('[ChildViewComponent] - ngAfterViewInit');
  }

  ngAfterViewChecked() {
    console.log('[ChildViewComponent] - ngAfterViewChecked');
  }

  ngOnDestroy() {
    console.log('[ChildViewComponent] - ngOnDestroy');
  }

}
