import {
  Component,
  OnInit, OnChanges, DoCheck,
  AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy,
  ContentChild,
  ViewChild
} from '@angular/core';

import { ChildViewComponent } from './../child-view/child-view.component';

interface Person {
  name: string;
}

@Component({
  selector: 'app-parent-view',
  templateUrl: './parent-view.component.html',
  styleUrls: ['./parent-view.component.css']
})
export class ParentViewComponent implements
  OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  inputStr: string;
  inputObj: Person;
  // @ContentChild(ChildViewComponent) contentChildViewComp: ChildViewComponent;
  @ViewChild(ChildViewComponent) viewChildViewComp: ChildViewComponent;
  constructor() {
    console.log('[ParentViewComponent] - constructor');
    this.inputStr = 'abc';
    this.inputObj = { name: '' };
  }

  ngOnChanges() {
    console.log('[ParentViewComponent] - ngOnChanges');

  }

  ngOnInit() {
    console.log('[ParentViewComponent] - ngOnInit');
  }

  ngDoCheck() {
    console.log('[ParentViewComponent] - ngDoCheck');
  }

  ngAfterContentInit() {
    console.log('[ParentViewComponent] - ngAfterContentInit');
    // this.contentChildViewComp.increment();

  }

  ngAfterContentChecked() {
    console.log('[ParentViewComponent] - ngAfterContentChecked');
    // this.contentChildViewComp.increment();

  }

  ngAfterViewInit() {
    console.log('[ParentViewComponent] - ngAfterViewInit');
    // this.viewChildViewComp.increment();

  }

  ngAfterViewChecked() {
    console.log('[ParentViewComponent] - ngAfterViewChecked');
    this.viewChildViewComp.increment();


  }

  ngOnDestroy() {
    console.log('[ParentViewComponent] - ngOnDestroy');
  }

  changeInputValue(val) {
    this.inputStr = val;
  }

  changeInputObject(val) {
    this.inputObj.name = val;
  }

  changeInputFullObject(val) {
    this.inputObj = { name: val };
  }
}
