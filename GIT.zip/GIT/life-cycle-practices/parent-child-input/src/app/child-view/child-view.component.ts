import {
  Component,
  OnInit, OnChanges, DoCheck,
  AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy,
  Input
} from '@angular/core';

@Component({
  selector: 'app-child-view',
  templateUrl: './child-view.component.html',
  styleUrls: ['./child-view.component.css']
})
export class ChildViewComponent implements
  OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

  @Input() inputVal: string;
  @Input() inputObject: object;
  constructor() {
    console.log('[ChildViewComponent] - constructor');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngOnChanges() {
    console.log('[ChildViewComponent] - ngOnChanges');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngOnInit() {
    console.log('[ChildViewComponent] - ngOnInit');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngDoCheck() {
    console.log('[ChildViewComponent] - ngDoCheck');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngAfterContentInit() {
    console.log('[ChildViewComponent] - ngAfterContentInit');
    console.log('inputVal: ', this.inputVal, this.inputObject);

  }

  ngAfterContentChecked() {
    console.log('[ChildViewComponent] - ngAfterContentChecked');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngAfterViewInit() {
    console.log('[ChildViewComponent] - ngAfterViewInit');
    console.log('inputVal: ', this.inputVal, this.inputObject);

  }

  ngAfterViewChecked() {
    console.log('[ChildViewComponent] - ngAfterViewChecked');
    console.log('inputVal: ', this.inputVal, this.inputObject);
  }

  ngOnDestroy() {
    console.log('[ChildViewComponent] - ngOnDestroy');
  }

}
