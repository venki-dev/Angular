import {
  Component,
  OnInit, OnChanges, DoCheck,
  AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy
} from '@angular/core';

interface Person {
  name: string;
}

@Component({
  selector: 'app-parent-view',
  templateUrl: './parent-view.component.html',
  styleUrls: ['./parent-view.component.css']
})
export class ParentViewComponent implements
  OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  inputStr: string;
  inputObj: Person;
  constructor() {
    console.log('[ParentViewComponent] - constructor');
    this.inputStr = 'abc';
    this.inputObj = { name: ''};
  }

  ngOnChanges() {
    console.log('[ParentViewComponent] - ngOnChanges');

  }

  ngOnInit() {
    console.log('[ParentViewComponent] - ngOnInit');

  }

  ngDoCheck() {
    console.log('[ParentViewComponent] - ngDoCheck');
  }

  ngAfterContentInit() {
    console.log('[ParentViewComponent] - ngAfterContentInit');

  }

  ngAfterContentChecked() {
    console.log('[ParentViewComponent] - ngAfterContentChecked');
  }

  ngAfterViewInit() {
    console.log('[ParentViewComponent] - ngAfterViewInit');
  }

  ngAfterViewChecked() {
    console.log('[ParentViewComponent] - ngAfterViewChecked');
  }

  ngOnDestroy() {
    console.log('[ParentViewComponent] - ngOnDestroy');
  }

  changeInputValue(val) {
    this.inputStr = val;
  }

  changeInputObject(val) {
    this.inputObj.name = val;
  }

  changeInputFullObject(val) {
    this.inputObj = { name: val };
  }
}
