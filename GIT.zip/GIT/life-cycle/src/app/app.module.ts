import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { FileSelectDirective } from 'ng2-file-upload';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';


import { AppComponent } from './app.component';




@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
    
  ],
  declarations: [
    AppComponent,
    FileSelectDirective
  ],
  providers: [

  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
