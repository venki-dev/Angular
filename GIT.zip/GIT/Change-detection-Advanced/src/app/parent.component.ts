import { Component } from '@angular/core';

import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-parent',
  template: `
    <div>{{title}}</div>
    <div><input #word type="text" /></div>
    <button (click)="addWord(word.value)">Add Word</button> <br />
    <button (click)="addFood(word.value)">Add Food</button>
    <app-child1 [data]="words"></app-child1>
    <app-child2 [data]="words"></app-child2>
    <app-child3 [data]="foods"></app-child3>
  `,
})
export class AppParentComponent {
    title = 'Parent Component';
    words: Array<string> = ['Apple', 'Orange', 'Mango'];
    foods = new BehaviorSubject(['Bacon', 'Letuce', 'Tomatoes']);

    addWord(val) {
        this.words.push(val);
    }

    addFood(food) {
      this.foods.next(food);
    }
}
