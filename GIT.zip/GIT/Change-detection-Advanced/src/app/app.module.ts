import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppParentComponent } from './parent.component';
import { AppChildComponent1 } from './child.component1';
import { AppChildComponent2 } from './child.component2';
import { AppChildComponent3 } from './child.component3';


@NgModule({
  declarations: [
    AppComponent,
    AppParentComponent,
    AppChildComponent1,
    AppChildComponent2,
    AppChildComponent3
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
