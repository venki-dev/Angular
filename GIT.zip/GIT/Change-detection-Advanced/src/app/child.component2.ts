import { Component, Input, OnChanges, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-child2 ',
  template: `
    <div>{{title}} ChangeDetectionStrategy.OnPush</div>
    <ul>
      <li *ngFor="let item of data">{{item}}</li>
    </ul>
    <button (click)="refresh()">Refresh Data</button>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppChildComponent2 implements OnChanges {
  title = 'Child 2 Component';
  @Input() data: string[];

  constructor(private cd: ChangeDetectorRef) {

  }
  ngOnChanges() {
    console.log('[AppChildComponent2 -- ngOnChanges]');
  }

  refresh() {
    this.cd.detectChanges();
  }
  
}
