import { Component, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-child1',
  template: `
    <div>{{title}} ChangeDetectionStrategy.Default</div>
    <ul>
      <li *ngFor="let item of data">{{item}}</li>
    </ul>
  `,
})
export class AppChildComponent1 implements OnChanges {
  title = 'Child 1 Component';
  @Input() data: string[];

  ngOnChanges() {
    console.log('[AppChildComponent1 -- ngOnChanges]');
  }
}
