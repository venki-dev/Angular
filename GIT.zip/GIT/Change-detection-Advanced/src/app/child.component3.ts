import { Component, Input, OnChanges, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { Observable } from 'rxjs';

@Component({
  selector: 'app-child3',
  template: `
    <div>{{title}} ChangeDetectionStrategy.OnPush</div>
    <ul>
      <li *ngFor="let item of foods">{{item}}</li>
    </ul>
    <button (click)="refresh()">Refresh Data</button>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppChildComponent3 implements OnChanges, OnInit {
  title = 'Child 3 Component';
  @Input() data: Observable<any>;
  foods: string[] = [];
  constructor(private cd: ChangeDetectorRef) {

  }
  ngOnChanges() {
    console.log('[AppChildComponent2 -- ngOnChanges]');
  }

  ngOnInit() {
    this.data.subscribe(food => {
      this.foods = [...this.foods, ...food];
      this.cd.markForCheck();
    })
  }

  refresh() {
    this.cd.detectChanges();
  }

}
