import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactsRouterModule } from './contacts-routing.module';
import { ContactListComponent } from './contact-list/contact-list.component';
import { ContactDetailComponent } from './contact-detail/contact-detail.component';
import { AddressComponent } from './address/address.component';


@NgModule({
    imports: [CommonModule, ContactsRouterModule],
    declarations: [ContactListComponent, ContactDetailComponent, AddressComponent]
})
export class ContactsModule { }

