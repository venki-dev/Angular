import { Component, OnInit } from '@angular/core';

import { ProductsService } from './../products.service';
import { Product } from './../product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[];
  constructor(private productsService: ProductsService) { }

  ngOnInit() {
    this.productsService.getAllProducts().subscribe(
      items => { this.products = items; console.log(items);},
      error => console.log('error in getting all prodcuts', error)
    )
  }

  trackProduct(index, product) {
    console.log(product.name);
    return product ? product.name : undefined;
  }
}
