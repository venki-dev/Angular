import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-products',
  templateUrl: './active-products.component.html',
  styleUrls: ['./active-products.component.css']
})
export class ActiveProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
