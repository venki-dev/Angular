import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inactive-products',
  templateUrl: './inactive-products.component.html',
  styleUrls: ['./inactive-products.component.css']
})
export class InactiveProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
