import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductsComponent } from './products/products.component';
import { InactiveProductsComponent } from './inactive-products/inactive-products.component';
import { ActiveProductsComponent } from './active-products/active-products.component';

const routes: Routes = [{
    path: '', component: ProductsComponent
    , children: [{
        path: 'inactive', component: InactiveProductsComponent
    }, {
        path: 'active', component: ActiveProductsComponent
    }]
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]

})
export class ProductsRoutingModule { }