import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { ProductsRoutingModule } from './products-routing.module';
import { ProductsComponent } from './products/products.component';
import { InactiveProductsComponent } from './inactive-products/inactive-products.component';
import { ActiveProductsComponent } from './active-products/active-products.component';

@NgModule({
    imports: [CommonModule, ProductsRoutingModule],
    declarations: [ProductsComponent, InactiveProductsComponent, ActiveProductsComponent]

})
export class ProductsModule { }
