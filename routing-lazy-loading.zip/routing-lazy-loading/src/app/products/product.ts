export interface Product {
    name: string;
    imgUrl: string;
    proce: number;
    active: boolean
}