import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ContactListComponent } from './contacts/contact-list/contact-list.component'
import { ContactDetailComponent } from './contacts/contact-detail/contact-detail.component'
import { AddressComponent } from './contacts/address/address.component'
import { PageNotFoundComponent } from './page-not-found/page-not-found.component'
import { UsersComponent } from './users/users.component'


const routes: Routes = [{
    path: '', redirectTo: 'users', pathMatch: 'full'
}, {
    path: 'users', component: UsersComponent
}, {
    path: 'contacts', loadChildren: './contacts/contacts.module#ContactsModule'
}, {
    // path: 'products', loadChildren: './products/products.module#ProductsModule'
    path: 'products', loadChildren: () => import('./products/products.module').then(m => m.ProductsModule)
} /*, {
    path: 'contact/:id', component: ContactDetailComponent
}, {
    path: 'address', component: AddressComponent
} */,
{
    path: '**', component: PageNotFoundComponent
}];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRouterModule { }
